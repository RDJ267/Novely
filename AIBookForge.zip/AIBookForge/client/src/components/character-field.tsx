import React from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { Trash2, User, UserRound, ScrollText } from 'lucide-react';
import { Character } from '@/types';
import { Button } from './ui/button';

interface CharacterFieldProps {
  index: number;
  onRemove: () => void;
  showRemoveButton: boolean;
}

const CharacterField: React.FC<CharacterFieldProps> = ({ index, onRemove, showRemoveButton }) => {
  const { control, formState: { errors } } = useFormContext();
  const fieldName = `characters.${index}` as const;
  const fieldErrors = errors.characters?.[index] as { 
    name?: { message?: string };
    role?: { message?: string };
    description?: { message?: string };
  };

  return (
    <div className="character-entry p-5 border border-gray-200 rounded-lg relative bg-white/80 shadow-sm hover:shadow-md transition-shadow duration-300">
      <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-full"></div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
            <UserRound className="h-4 w-4 mr-1 text-primary/70" />
            Name
          </label>
          <Controller
            control={control}
            name={`${fieldName}.name`}
            render={({ field }) => (
              <input
                {...field}
                type="text"
                className={`w-full px-4 py-2.5 border ${fieldErrors?.name ? 'border-red-500' : 'border-gray-200'} rounded-lg shadow-sm focus:ring-primary/30 focus:border-primary transition-colors`}
                placeholder="Character name"
              />
            )}
          />
          {fieldErrors?.name && (
            <p className="mt-1 text-sm text-red-600">{fieldErrors.name.message}</p>
          )}
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
            <User className="h-4 w-4 mr-1 text-primary/70" />
            Role
          </label>
          <Controller
            control={control}
            name={`${fieldName}.role`}
            render={({ field }) => (
              <input
                {...field}
                type="text"
                className={`w-full px-4 py-2.5 border ${fieldErrors?.role ? 'border-red-500' : 'border-gray-200'} rounded-lg shadow-sm focus:ring-primary/30 focus:border-primary transition-colors`}
                placeholder="Protagonist, Antagonist, etc."
              />
            )}
          />
          {fieldErrors?.role && (
            <p className="mt-1 text-sm text-red-600">{fieldErrors.role.message}</p>
          )}
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
          <ScrollText className="h-4 w-4 mr-1 text-primary/70" />
          Description
        </label>
        <Controller
          control={control}
          name={`${fieldName}.description`}
          render={({ field }) => (
            <textarea
              {...field}
              className={`w-full px-4 py-2.5 border ${fieldErrors?.description ? 'border-red-500' : 'border-gray-200'} rounded-lg shadow-sm focus:ring-primary/30 focus:border-primary transition-colors`}
              rows={3}
              placeholder="Physical traits, personality, background, motivations, and character arc..."
            />
          )}
        />
        {fieldErrors?.description && (
          <p className="mt-1 text-sm text-red-600">{fieldErrors.description.message}</p>
        )}
        <p className="mt-1 text-xs text-gray-500">
          The more detail you provide about your character, the more developed they'll be in your story.
        </p>
      </div>
      
      {showRemoveButton && (
        <Button 
          type="button" 
          variant="ghost" 
          size="sm"
          className="absolute top-3 right-3 text-gray-500 hover:text-red-500 hover:bg-red-50 z-10"
          onClick={onRemove}
        >
          <Trash2 className="h-4 w-4" />
          <span className="sr-only">Remove character</span>
        </Button>
      )}
    </div>
  );
};

export default CharacterField;
