import React from 'react';
import { Link } from 'wouter';
import { BookOpen, Sparkles, Library, HelpCircle } from 'lucide-react';
import { Button } from './ui/button';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-primary/90 to-primary py-4 sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="bg-white p-2 rounded-full shadow-sm">
            <BookOpen className="w-7 h-7 text-primary" />
          </div>
          <Link href="/" className="text-2xl font-bold text-white flex items-center">
            Novel<span className="text-gray-100">AI</span>
            <Sparkles className="ml-1 w-5 h-5 text-yellow-300" />
          </Link>
        </div>
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            <li>
              <Link href="/" className="text-white hover:text-yellow-200 transition-colors font-medium flex items-center">
                <BookOpen className="mr-1 w-4 h-4" />
                Create
              </Link>
            </li>
            <li>
              <button className="text-white hover:text-yellow-200 transition-colors font-medium flex items-center bg-transparent border-0 p-0 cursor-pointer">
                <Library className="mr-1 w-4 h-4" />
                Examples
              </button>
            </li>
            <li>
              <button className="text-white hover:text-yellow-200 transition-colors font-medium flex items-center bg-transparent border-0 p-0 cursor-pointer">
                <HelpCircle className="mr-1 w-4 h-4" />
                Help
              </button>
            </li>
          </ul>
        </nav>
        <div className="hidden md:block">
          <Button variant="secondary" className="bg-white text-primary hover:bg-gray-100">
            Get Started
          </Button>
        </div>
        <button className="md:hidden text-white">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </header>
  );
};

export default Header;
