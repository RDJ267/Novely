import React from 'react';
import { BookOpen, Sparkles, Twitter, Github, Facebook, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Logo and Description */}
        <div className="flex flex-col items-center mb-12 text-center">
          <div className="flex items-center mb-4">
            <BookOpen className="w-8 h-8 text-primary mr-2" />
            <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-200">
              Novel<span className="text-yellow-300">AI</span>
              <Sparkles className="inline ml-1 w-5 h-5 text-yellow-300" />
            </h2>
          </div>
          <p className="text-gray-300 max-w-lg text-center">
            Transforming your creative ideas into complete novels with the power of advanced AI.
            Craft entire books with just a few prompts.
          </p>
        </div>
        
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-6 border-t border-b border-gray-700">
          <div>
            <h3 className="text-lg font-semibold mb-4 text-purple-200">About Our AI</h3>
            <p className="text-gray-400">
              Our state-of-the-art AI uses GPT technology to generate coherent, 
              engaging novels based on your creative direction. From character development 
              to plot twists, let our AI handle the details.
            </p>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4 text-purple-200">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">How It Works</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Examples</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Pricing</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Support</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4 text-purple-200">Legal</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Content Guidelines</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Copyright Information</a></li>
            </ul>
          </div>
        </div>
        
        {/* Social Media and Copyright */}
        <div className="mt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-400 mb-4 md:mb-0">
            <p>&copy; {new Date().getFullYear()} NovelAI. All rights reserved.</p>
            <p className="mt-1 text-sm font-medium text-primary/70">By: Vinayak P. Gupta</p>
          </div>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Twitter className="w-5 h-5" />
              <span className="sr-only">Twitter</span>
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Github className="w-5 h-5" />
              <span className="sr-only">GitHub</span>
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Facebook className="w-5 h-5" />
              <span className="sr-only">Facebook</span>
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Instagram className="w-5 h-5" />
              <span className="sr-only">Instagram</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
