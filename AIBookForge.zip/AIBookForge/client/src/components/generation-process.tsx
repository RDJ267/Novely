import React, { useEffect, useState } from 'react';
import { Book, GenerationStatus, GenerationStage } from '@/types';
import { Check } from 'lucide-react';

interface GenerationProcessProps {
  bookId: number;
  status: GenerationStatus;
  onCancel: () => void;
}

const GenerationProcess: React.FC<GenerationProcessProps> = ({ 
  bookId, 
  status, 
  onCancel 
}) => {
  
  // Define all possible generation stages
  const [stages, setStages] = useState<GenerationStage[]>([
    { id: 1, name: "Analyzing story inputs", status: "pending" },
    { id: 2, name: "Creating character profiles", status: "pending" },
    { id: 3, name: "Developing story structure", status: "pending" },
    { id: 4, name: "Writing chapters and scenes", status: "pending" },
    { id: 5, name: "Refining prose and dialogues", status: "pending" },
    { id: 6, name: "Final review and formatting", status: "pending" },
  ]);

  // Update stages based on generation progress
  useEffect(() => {
    const progress = status.progress;
    const updatedStages = [...stages];

    // Update stage statuses based on progress
    if (progress < 5) {
      updatedStages[0].status = "active";
    } else if (progress < 15) {
      updatedStages[0].status = "completed";
      updatedStages[1].status = "active";
    } else if (progress < 30) {
      updatedStages[0].status = "completed";
      updatedStages[1].status = "completed";
      updatedStages[2].status = "active";
    } else if (progress < 70) {
      updatedStages[0].status = "completed";
      updatedStages[1].status = "completed";
      updatedStages[2].status = "completed";
      updatedStages[3].status = "active";
    } else if (progress < 90) {
      updatedStages[0].status = "completed";
      updatedStages[1].status = "completed";
      updatedStages[2].status = "completed";
      updatedStages[3].status = "completed";
      updatedStages[4].status = "active";
    } else if (progress < 100) {
      updatedStages[0].status = "completed";
      updatedStages[1].status = "completed";
      updatedStages[2].status = "completed";
      updatedStages[3].status = "completed";
      updatedStages[4].status = "completed";
      updatedStages[5].status = "active";
    } else if (progress === 100) {
      updatedStages.forEach(stage => {
        stage.status = "completed";
      });
    }

    setStages(updatedStages);
  }, [status.progress]);

  // Get status message and substatus
  const getStatusMessage = () => {
    switch (status.status) {
      case 'started':
        return "Starting book generation...";
      case 'generating_outline':
        return "Crafting your book outline...";
      case 'generating_chapters':
        return "Writing your novel...";
      case 'completed':
        return "Book generation completed!";
      case 'error':
        return "Error during generation";
      default:
        return "Processing...";
    }
  };

  const getSubstatusMessage = () => {
    if (status.message) return status.message;
    
    // Fallback messages based on progress
    if (status.progress < 15) return "Analyzing your inputs and planning the narrative";
    if (status.progress < 30) return "Developing the story structure";
    if (status.progress < 70) return "Writing chapters and scenes";
    if (status.progress < 90) return "Refining the prose and dialogue";
    return "Finalizing and formatting your book";
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
      <div className="px-6 py-6 border-b border-gray-200">
        <h3 className="text-xl font-semibold text-gray-900">Generating Your Book</h3>
        <p className="text-gray-600 mt-1">Our AI is crafting your novel based on your inputs</p>
      </div>
      
      <div className="px-6 py-8">
        {/* Processing Status */}
        <div className="text-center mb-8">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mb-4"></div>
          <h4 className="text-lg font-medium text-gray-900 mb-2">{getStatusMessage()}</h4>
          <p className="text-gray-600">{getSubstatusMessage()}</p>
        </div>
        
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium text-gray-700">Overall Progress</span>
            <span className="text-sm font-medium text-gray-700">{status.progress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-blue-500 h-2.5 rounded-full" 
              style={{ width: `${status.progress}%` }}
            ></div>
          </div>
        </div>
        
        {/* Generation Stages */}
        <div className="space-y-3">
          {stages.map((stage) => (
            <div className="flex items-center" key={stage.id}>
              {stage.status === 'completed' ? (
                <div className="rounded-full w-6 h-6 flex items-center justify-center bg-green-500 mr-3">
                  <Check className="w-4 h-4 text-white" />
                </div>
              ) : stage.status === 'active' ? (
                <div className="rounded-full w-6 h-6 flex items-center justify-center bg-blue-500 animate-pulse-slow mr-3">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              ) : (
                <div className="rounded-full w-6 h-6 flex items-center justify-center bg-gray-300 mr-3">
                  <span className="text-white text-xs font-medium">{stage.id}</span>
                </div>
              )}
              <span className={`${stage.status === 'pending' ? 'text-gray-500' : 'text-gray-700'}`}>
                {stage.name}
              </span>
            </div>
          ))}
        </div>
        
        {/* Cancel Option */}
        <div className="mt-8 text-center">
          <button
            type="button"
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            onClick={onCancel}
          >
            Cancel Generation
          </button>
        </div>
      </div>
    </div>
  );
};

export default GenerationProcess;
