import React from 'react';
import { Sparkles, Pencil, Lightbulb, Download } from 'lucide-react';

const WorkflowSteps: React.FC = () => {
  return (
    <div className="mb-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">How It Works</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Our AI-powered platform transforms your creative ideas into complete novels in just three simple steps
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Step 1 */}
        <div className="bg-white rounded-xl shadow-lg hover:shadow-xl p-8 transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -mr-10 -mt-10 transition-all duration-300 group-hover:bg-primary/10"></div>
          
          <div className="rounded-full bg-primary/10 w-16 h-16 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-all duration-300">
            <Pencil className="w-7 h-7 text-primary" />
          </div>
          
          <div className="flex items-center mb-4">
            <div className="rounded-full bg-primary w-6 h-6 flex items-center justify-center mr-3">
              <span className="text-white font-medium text-sm">1</span>
            </div>
            <h3 className="font-bold text-xl text-gray-800">Describe Your Book</h3>
          </div>
          
          <p className="text-gray-600 mb-4">
            Share your storyline, characters, settings, and key scenes. 
            The more details you provide, the better your novel will be.
          </p>
          
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Define your genre and writing style</span>
            </li>
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Create detailed character profiles</span>
            </li>
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Outline key plot points and scenes</span>
            </li>
          </ul>
        </div>
        
        {/* Step 2 */}
        <div className="bg-white rounded-xl shadow-lg hover:shadow-xl p-8 transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -mr-10 -mt-10 transition-all duration-300 group-hover:bg-primary/10"></div>
          
          <div className="rounded-full bg-primary/10 w-16 h-16 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-all duration-300">
            <Sparkles className="w-7 h-7 text-primary" />
          </div>
          
          <div className="flex items-center mb-4">
            <div className="rounded-full bg-primary w-6 h-6 flex items-center justify-center mr-3">
              <span className="text-white font-medium text-sm">2</span>
            </div>
            <h3 className="font-bold text-xl text-gray-800">AI Generation</h3>
          </div>
          
          <p className="text-gray-600 mb-4">
            Our advanced AI system carefully analyzes your inputs and transforms
            them into a complete, cohesive novel with rich narrative.
          </p>
          
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Creates detailed chapter outlines</span>
            </li>
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Develops meaningful character arcs</span>
            </li>
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Writes 85,000+ words of polished prose</span>
            </li>
          </ul>
        </div>
        
        {/* Step 3 */}
        <div className="bg-white rounded-xl shadow-lg hover:shadow-xl p-8 transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -mr-10 -mt-10 transition-all duration-300 group-hover:bg-primary/10"></div>
          
          <div className="rounded-full bg-primary/10 w-16 h-16 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-all duration-300">
            <Download className="w-7 h-7 text-primary" />
          </div>
          
          <div className="flex items-center mb-4">
            <div className="rounded-full bg-primary w-6 h-6 flex items-center justify-center mr-3">
              <span className="text-white font-medium text-sm">3</span>
            </div>
            <h3 className="font-bold text-xl text-gray-800">Download Your Book</h3>
          </div>
          
          <p className="text-gray-600 mb-4">
            Review, download, and share your complete AI-generated novel.
            Make edits or regenerate sections as needed.
          </p>
          
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Preview chapters before downloading</span>
            </li>
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Export in multiple formats</span>
            </li>
            <li className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
              <span>Request revisions if needed</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default WorkflowSteps;
