import React, { useState, useEffect } from 'react';
import { Book, Chapter } from '@/types';
import { useQuery } from '@tanstack/react-query';
import { getBookChapters, getBookDownloadUrl } from '@/lib/book-service';
import { useToast } from '@/hooks/use-toast';
import { Download, RotateCw, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { Link } from 'wouter';

interface BookResultProps {
  book: Book;
  onRegenerate: () => void;
}

const BookResult: React.FC<BookResultProps> = ({ book, onRegenerate }) => {
  const { toast } = useToast();
  const [selectedChapterIndex, setSelectedChapterIndex] = useState(0);

  // Fetch chapters
  const { data: chapters = [], isLoading, error } = useQuery({
    queryKey: [`/api/books/${book.id}/chapters`],
    enabled: book.status === 'completed'
  });

  useEffect(() => {
    if (error) {
      toast({
        title: "Error loading chapters",
        description: error instanceof Error ? error.message : "Failed to load chapters",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  // Handle chapter navigation
  const handlePreviousChapter = () => {
    if (selectedChapterIndex > 0) {
      setSelectedChapterIndex(selectedChapterIndex - 1);
    }
  };

  const handleNextChapter = () => {
    if (selectedChapterIndex < chapters.length - 1) {
      setSelectedChapterIndex(selectedChapterIndex + 1);
    }
  };

  const handleChapterSelect = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const index = parseInt(event.target.value);
    setSelectedChapterIndex(index);
  };

  // Handle download
  const handleDownload = () => {
    window.location.href = getBookDownloadUrl(book.id);
  };

  // Get selected chapter
  const selectedChapter = chapters[selectedChapterIndex] as Chapter | undefined;

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
      <div className="px-6 py-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-semibold text-gray-900">Your Generated Book</h3>
          <Button
            onClick={handleDownload}
            className="inline-flex items-center"
          >
            <Download className="-ml-1 mr-2 h-5 w-5" />
            Download Book
          </Button>
        </div>
      </div>
      
      <div className="px-6 py-6">
        {/* Book Info */}
        <div className="mb-6 pb-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{book.title}</h2>
          <div className="flex items-center text-sm text-gray-600 mb-4">
            <span className="mr-4">{book.genre}</span>
            <span>{book.wordCount ? `${book.wordCount.toLocaleString()} words` : "85,000+ words"}</span>
          </div>
          <p className="text-gray-700">
            {book.storyline}
          </p>
        </div>
        
        {/* Book Preview */}
        <div className="mb-6">
          <h4 className="font-medium text-gray-900 mb-3">Book Preview</h4>
          
          <div className="bg-gray-50 p-6 rounded-md max-h-96 overflow-y-auto">
            {isLoading ? (
              <div className="flex justify-center items-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                <span className="ml-2 text-gray-600">Loading chapters...</span>
              </div>
            ) : chapters.length === 0 ? (
              <div className="text-center py-8 text-gray-600">
                No chapters available.
              </div>
            ) : (
              <>
                {/* Chapter Selection */}
                <div className="mb-4 flex items-center">
                  <label htmlFor="chapter-select" className="block text-sm font-medium text-gray-700 mr-2">Jump to:</label>
                  <select
                    id="chapter-select"
                    className="flex-grow max-w-xs px-3 py-1 text-sm border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    onChange={handleChapterSelect}
                    value={selectedChapterIndex}
                  >
                    {chapters.map((chapter, index) => (
                      <option key={chapter.id} value={index}>
                        {chapter.title}
                      </option>
                    ))}
                  </select>
                </div>
                
                {/* Chapter Content */}
                {selectedChapter && (
                  <div className="prose max-w-none">
                    <h3 className="text-xl font-semibold mb-4">{selectedChapter.title}</h3>
                    {selectedChapter.content.split('\n\n').map((paragraph, idx) => (
                      <p key={idx}>{paragraph}</p>
                    ))}
                  </div>
                )}
                
                {/* Navigation */}
                <div className="flex justify-between mt-6">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handlePreviousChapter}
                    disabled={selectedChapterIndex === 0}
                  >
                    Previous Chapter
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleNextChapter}
                    disabled={selectedChapterIndex === chapters.length - 1}
                  >
                    Next Chapter
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
        
        {/* Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button
            variant="outline"
            className="inline-flex justify-center items-center"
            onClick={onRegenerate}
          >
            <RotateCw className="mr-2 h-5 w-5 text-gray-500" />
            Regenerate with Edits
          </Button>
          <Link href="/">
            <Button
              className="inline-flex justify-center items-center w-full"
            >
              <Plus className="mr-2 h-5 w-5" />
              Create a New Book
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BookResult;
