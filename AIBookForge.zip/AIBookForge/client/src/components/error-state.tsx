import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { ErrorState as ErrorStateType } from '@/types';

interface ErrorStateProps {
  error: ErrorStateType;
  onRetry: () => void;
  onEdit: () => void;
}

const ErrorState: React.FC<ErrorStateProps> = ({ error, onRetry, onEdit }) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
      <div className="px-6 py-6 border-b border-gray-200 bg-red-50">
        <div className="flex items-center">
          <AlertCircle className="h-6 w-6 text-red-500 mr-3" />
          <h3 className="text-xl font-semibold text-red-800">Generation Failed</h3>
        </div>
      </div>
      
      <div className="px-6 py-6">
        <div className="mb-6">
          <h4 className="font-medium text-gray-900 mb-2">We encountered an issue</h4>
          <p className="text-gray-700">
            {error.message || "Our AI was unable to complete your book generation. This could be due to high system load or an issue with the input provided."}
          </p>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-md mb-6">
          <h5 className="font-medium text-gray-800 mb-2">Suggestions to resolve this:</h5>
          <ul className="list-disc pl-5 text-gray-600 space-y-1">
            <li>Try again in a few minutes when our system has less load</li>
            <li>Provide more detailed character descriptions and storyline</li>
            <li>Check if your content adheres to our content guidelines</li>
            <li>If the problem persists, contact our support team</li>
          </ul>
        </div>
        
        <div className="flex space-x-4">
          <Button 
            onClick={onRetry}
            className="px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md shadow-sm hover:bg-red-700 focus:outline-none"
          >
            Try Again
          </Button>
          <Button 
            onClick={onEdit}
            variant="outline"
            className="px-4 py-2 text-sm font-medium"
          >
            Edit Inputs
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ErrorState;
