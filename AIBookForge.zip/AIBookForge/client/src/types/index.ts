export interface Character {
  name: string;
  role: string;
  description: string;
}

export interface BookFormData {
  title: string;
  genre: string;
  storyline: string;
  characters: Character[];
  keyScenes: string;
  additionalNotes?: string;
  writingStyle: string;
  pov: string;
}

export interface Book {
  id: number;
  title: string;
  genre: string;
  storyline: string;
  characters: Character[];
  keyScenes: string;
  additionalNotes?: string;
  writingStyle: string;
  pov: string;
  content?: string | null;
  wordCount?: number | null;
  status: 'pending' | 'started' | 'generating_outline' | 'generating_chapters' | 'completed' | 'error';
  createdAt: string;
  userId?: number | null;
}

export interface Chapter {
  id: number;
  bookId: number;
  title: string;
  content: string;
  orderIndex: number;
}

export interface GenerationStatus {
  id: number;
  bookId: number;
  status: string;
  progress: number;
  message?: string;
  createdAt: string;
}

export interface GenerationStage {
  id: number;
  name: string;
  status: 'completed' | 'active' | 'pending';
}

export interface ErrorState {
  message: string;
  retry?: () => void;
}
