import React, { useEffect, useState } from 'react';
import { useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Book, GenerationStatus, ErrorState } from '@/types';
import { getBook, getGenerationStatus, pollGenerationStatus } from '@/lib/book-service';
import Header from '@/components/header';
import Footer from '@/components/footer';
import GenerationProcess from '@/components/generation-process';
import BookResult from '@/components/book-result';
import ErrorStateComponent from '@/components/error-state';
import { useLocation } from 'wouter';

const BookViewer: React.FC = () => {
  const [, params] = useRoute<{ id: string }>('/book/:id');
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const bookId = params ? parseInt(params.id) : -1;

  const [status, setStatus] = useState<GenerationStatus | null>(null);
  const [error, setError] = useState<ErrorState | null>(null);

  // Query for book data
  const bookQuery = useQuery({
    queryKey: [`/api/books/${bookId}`],
    enabled: bookId > 0,
    refetchInterval: (data) => {
      // Refetch completed or error books less frequently
      if (data?.status === 'completed' || data?.status === 'error') {
        return false;
      }
      return 5000; // 5 seconds
    }
  });

  // Initial status query
  const statusQuery = useQuery({
    queryKey: [`/api/books/${bookId}/status`],
    enabled: bookId > 0 && bookQuery.data?.status !== 'completed' && bookQuery.data?.status !== 'error',
  });

  // Set up polling for generation status
  useEffect(() => {
    if (!bookId || !bookQuery.data) return;
    
    // Skip polling for completed or error books
    if (bookQuery.data.status === 'completed' || bookQuery.data.status === 'error') {
      return;
    }
    
    // Start polling for status updates
    const stopPolling = pollGenerationStatus(bookId, (newStatus) => {
      setStatus(newStatus);
      
      // Show toast for completed generation
      if (newStatus.status === 'completed' && status?.status !== 'completed') {
        toast({
          title: "Book generation complete!",
          description: "Your book has been successfully generated and is ready to read.",
        });
        // Refresh book data
        bookQuery.refetch();
      }
      
      // Handle error
      if (newStatus.status === 'error') {
        setError({
          message: newStatus.message || "An error occurred during book generation.",
          retry: () => handleRetry()
        });
      }
    });
    
    // Cleanup polling on unmount
    return () => stopPolling();
  }, [bookId, bookQuery.data?.status, status?.status]);

  // Set initial status from status query
  useEffect(() => {
    if (statusQuery.data && !status) {
      setStatus(statusQuery.data);
    }
  }, [statusQuery.data]);

  // Handle errors
  useEffect(() => {
    if (bookQuery.error) {
      toast({
        title: "Error loading book",
        description: bookQuery.error instanceof Error ? bookQuery.error.message : "Failed to load book data",
        variant: "destructive",
      });
      setError({
        message: "Unable to load book data. The book may not exist or there was a network error.",
      });
    }
  }, [bookQuery.error]);

  // Handle book error status
  useEffect(() => {
    if (bookQuery.data?.status === 'error') {
      setError({
        message: "There was an error generating your book. Please try again or modify your inputs.",
        retry: () => handleRetry()
      });
    }
  }, [bookQuery.data?.status]);

  // Handle retry generation
  const handleRetry = () => {
    // In a real application, this would call an API endpoint to retry generation
    toast({
      title: "Retry requested",
      description: "This feature is not implemented in the demo."
    });
  };

  // Handle regenerate with edits
  const handleRegenerate = () => {
    // In a real application, this would allow edits to the book parameters and restart generation
    toast({
      title: "Regenerate requested",
      description: "This feature is not implemented in the demo."
    });
  };

  // Handle cancel generation
  const handleCancelGeneration = () => {
    toast({
      title: "Generation cancelled",
      description: "Returning to home page"
    });
    navigate('/');
  };

  // Handle edit inputs (return to form)
  const handleEditInputs = () => {
    navigate('/');
  };

  // Render loading state
  if (bookQuery.isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mb-4"></div>
            <h2 className="text-xl font-medium text-gray-700">Loading book data...</h2>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Render main content based on book status
  const renderContent = () => {
    const book = bookQuery.data as Book | undefined;
    
    if (!book) {
      return null;
    }

    if (error) {
      return (
        <ErrorStateComponent 
          error={error} 
          onRetry={handleRetry} 
          onEdit={handleEditInputs} 
        />
      );
    }

    if (book.status === 'completed') {
      return <BookResult book={book} onRegenerate={handleRegenerate} />;
    }

    if (status) {
      return (
        <GenerationProcess 
          bookId={book.id} 
          status={status} 
          onCancel={handleCancelGeneration} 
        />
      );
    }

    return null;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="max-w-4xl mx-auto">
          {renderContent()}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default BookViewer;
