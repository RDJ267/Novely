import React from 'react';
import Header from '@/components/header';
import Footer from '@/components/footer';
import BookForm from '@/components/book-form';
import WorkflowSteps from '@/components/workflow-steps';
import { Button } from '@/components/ui/button';
import { Sparkles, BookOpen, ChevronDown } from 'lucide-react';

const Home: React.FC = () => {
  // Smooth scroll to the form section
  const scrollToForm = () => {
    const formElement = document.getElementById('book-form');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section with Background */}
        <section className="relative bg-gradient-to-b from-primary/95 to-primary text-white py-20">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMxLjIzIDAgMi4xOTguOTY4IDIuMTk4IDIuMnYxOS42YzAgMS4yMzItLjk2OCAyLjItMi4xOTggMi4ySDE4Yy0xLjIzIDAtMi4yLTEuMDEzLTIuMi0yLjI3VjIwLjI3YzAtMS4yNTggMS4wMS0yLjI3IDIuMi0yLjI3aDE4ek0xMi45NzcgMzVoLTIuOTU0QTEwLjAyNCAxMC4wMjQgMCAwMTAgMjQuOTc3di0yLjk1NEExMC4wMjUgMTAuMDI1IDAgMDExMC4wMjMgMTJoMi45NTRBMTAuMDI0IDEwLjAyNCAwIDAxMjMgMjIuMDIzdjIuOTU0QTEwLjAyNSAxMC4wMjUgMCAwMTEyLjk3NyAzNXoiIGZpbGw9IiNGRkYiIG9wYWNpdHk9Ii4xNSIvPjwvZz48L3N2Zz4=')] opacity-5"></div>
          </div>
          
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <div className="inline-flex items-center justify-center p-1 px-3 mb-6 bg-white/10 backdrop-blur-sm rounded-full text-white text-sm font-medium">
                <Sparkles className="w-4 h-4 mr-2 text-yellow-300" />
                AI-powered novel generation
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-200 leading-tight">
                Transform Your Ideas Into <br/>Complete Novels
              </h1>
              
              <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto mb-8">
                Describe your storyline, characters, and key scenes. Our advanced AI will generate 
                a complete 85,000-word novel based on your creative direction.
              </p>
              
              <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
                <Button 
                  size="lg" 
                  className="bg-white text-primary hover:bg-gray-100 font-medium"
                  onClick={scrollToForm}
                >
                  <BookOpen className="mr-2 h-5 w-5" />
                  Start Writing
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-white border-white hover:bg-white/10"
                >
                  View Examples
                </Button>
              </div>
              
              <div className="animate-bounce text-white/70 absolute left-1/2 -translate-x-1/2 bottom-4">
                <a href="#workflow" className="flex flex-col items-center">
                  <span className="text-sm mb-1">Learn More</span>
                  <ChevronDown className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </section>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="max-w-4xl mx-auto">
            {/* Workflow Steps */}
            <div id="workflow">
              <WorkflowSteps />
            </div>
            
            {/* Book Creation Form */}
            <div id="book-form">
              <BookForm />
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;
