import { apiRequest } from "./queryClient";
import { Book, BookFormData, Chapter, GenerationStatus } from "@/types";

// Create a new book generation request
export async function createBook(bookData: BookFormData): Promise<Book> {
  const response = await apiRequest("POST", "/api/books", bookData);
  const data = await response.json();
  return data.book;
}

// Get a book by ID
export async function getBook(id: number): Promise<Book> {
  const response = await apiRequest("GET", `/api/books/${id}`);
  return await response.json();
}

// Get all books
export async function getBooks(): Promise<Book[]> {
  const response = await apiRequest("GET", "/api/books");
  return await response.json();
}

// Get chapters for a book
export async function getBookChapters(bookId: number): Promise<Chapter[]> {
  const response = await apiRequest("GET", `/api/books/${bookId}/chapters`);
  return await response.json();
}

// Get generation status for a book
export async function getGenerationStatus(bookId: number): Promise<GenerationStatus> {
  const response = await apiRequest("GET", `/api/books/${bookId}/status`);
  return await response.json();
}

// Generate a download URL for a book
export function getBookDownloadUrl(bookId: number): string {
  return `/api/books/${bookId}/download`;
}

// Poll for generation status
export function pollGenerationStatus(bookId: number, callback: (status: GenerationStatus) => void, interval = 2000): () => void {
  const intervalId = setInterval(async () => {
    try {
      const status = await getGenerationStatus(bookId);
      callback(status);
      
      // Stop polling if status is completed or error
      if (status.status === 'completed' || status.status === 'error') {
        clearInterval(intervalId);
      }
    } catch (error) {
      console.error("Error polling for generation status:", error);
    }
  }, interval);
  
  // Return function to stop polling
  return () => clearInterval(intervalId);
}

export default {
  createBook,
  getBook,
  getBooks,
  getBookChapters,
  getGenerationStatus,
  getBookDownloadUrl,
  pollGenerationStatus
};
