import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Character schema for the book
export const characterSchema = z.object({
  name: z.string().min(1, "Character name is required"),
  role: z.string().min(1, "Character role is required"),
  description: z.string().min(1, "Character description is required"),
});

export type Character = z.infer<typeof characterSchema>;

// Book schema
export const books = pgTable("books", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  genre: text("genre").notNull(),
  storyline: text("storyline").notNull(),
  characters: jsonb("characters").notNull().$type<Character[]>(),
  keyScenes: text("key_scenes").notNull(),
  additionalNotes: text("additional_notes"),
  writingStyle: text("writing_style").notNull(),
  pov: text("pov").notNull(),
  content: text("content"),
  wordCount: integer("word_count"),
  status: text("status").notNull().default("pending"),
  createdAt: text("created_at").notNull(),
  userId: integer("user_id").references(() => users.id),
});

export const insertBookSchema = createInsertSchema(books)
  .omit({ id: true, content: true, wordCount: true, status: true, createdAt: true })
  .extend({
    characters: z.array(characterSchema),
  });

export const bookGenerationSchema = z.object({
  title: z.string().min(1, "Title is required"),
  genre: z.string().min(1, "Genre is required"),
  storyline: z.string().min(10, "Storyline must be at least 10 characters"),
  characters: z.array(characterSchema).min(1, "At least one character is required"),
  keyScenes: z.string().min(10, "Key scenes must be at least 10 characters"),
  additionalNotes: z.string().optional(),
  writingStyle: z.string().min(1, "Writing style is required"),
  pov: z.string().min(1, "Point of view is required"),
});

export type InsertBook = z.infer<typeof insertBookSchema>;
export type Book = typeof books.$inferSelect;
export type BookGeneration = z.infer<typeof bookGenerationSchema>;

// Book chapters for content organization
export const chapters = pgTable("chapters", {
  id: serial("id").primaryKey(),
  bookId: integer("book_id").notNull().references(() => books.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  orderIndex: integer("order_index").notNull(),
});

export const insertChapterSchema = createInsertSchema(chapters).omit({ id: true });

export type InsertChapter = z.infer<typeof insertChapterSchema>;
export type Chapter = typeof chapters.$inferSelect;

// Generation status for tracking progress
export const generationStatuses = pgTable("generation_statuses", {
  id: serial("id").primaryKey(),
  bookId: integer("book_id").notNull().references(() => books.id),
  status: text("status").notNull(),
  progress: integer("progress").notNull(),
  message: text("message"),
  createdAt: text("created_at").notNull(),
});

export const insertGenerationStatusSchema = createInsertSchema(generationStatuses).omit({ id: true });

export type InsertGenerationStatus = z.infer<typeof insertGenerationStatusSchema>;
export type GenerationStatus = typeof generationStatuses.$inferSelect;
