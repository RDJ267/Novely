import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { bookGenerationSchema } from "@shared/schema";
import { generateBookOutline, generateChapter } from "./lib/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  
  // Get book by ID
  apiRouter.get("/books/:id", async (req: Request, res: Response) => {
    try {
      const bookId = parseInt(req.params.id);
      const book = await storage.getBook(bookId);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      return res.json(book);
    } catch (error) {
      console.error("Error fetching book:", error);
      return res.status(500).json({ message: "Failed to fetch book" });
    }
  });
  
  // Get all books
  apiRouter.get("/books", async (req: Request, res: Response) => {
    try {
      // Optional user ID filter
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const books = await storage.listBooks(userId);
      return res.json(books);
    } catch (error) {
      console.error("Error fetching books:", error);
      return res.status(500).json({ message: "Failed to fetch books" });
    }
  });
  
  // Create a new book generation request
  apiRouter.post("/books", async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validatedData = bookGenerationSchema.parse(req.body);
      
      // Create a new book record
      const newBook = await storage.createBook({
        ...validatedData,
        userId: null, // No user authentication in this version
        createdAt: new Date().toISOString()
      });
      
      // Create initial generation status
      await storage.createGenerationStatus({
        bookId: newBook.id,
        status: "started",
        progress: 0,
        message: "Starting book generation",
        createdAt: new Date().toISOString()
      });
      
      // Start async process to generate the book
      generateBook(newBook.id, validatedData).catch(error => {
        console.error(`Error in book generation process for book ${newBook.id}:`, error);
      });
      
      return res.status(201).json({ 
        book: newBook, 
        message: "Book generation started successfully" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid book data", 
          errors: error.errors 
        });
      }
      
      console.error("Error creating book:", error);
      return res.status(500).json({ 
        message: "Failed to create book generation request" 
      });
    }
  });
  
  // Get chapters for a book
  apiRouter.get("/books/:id/chapters", async (req: Request, res: Response) => {
    try {
      const bookId = parseInt(req.params.id);
      const book = await storage.getBook(bookId);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      const chapters = await storage.getChaptersByBookId(bookId);
      return res.json(chapters);
    } catch (error) {
      console.error("Error fetching chapters:", error);
      return res.status(500).json({ message: "Failed to fetch chapters" });
    }
  });
  
  // Get generation status for a book
  apiRouter.get("/books/:id/status", async (req: Request, res: Response) => {
    try {
      const bookId = parseInt(req.params.id);
      const book = await storage.getBook(bookId);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      const status = await storage.getLatestGenerationStatus(bookId);
      if (!status) {
        return res.status(404).json({ message: "No generation status found" });
      }
      
      return res.json(status);
    } catch (error) {
      console.error("Error fetching generation status:", error);
      return res.status(500).json({ message: "Failed to fetch generation status" });
    }
  });
  
  // Download a book as text
  apiRouter.get("/books/:id/download", async (req: Request, res: Response) => {
    try {
      const bookId = parseInt(req.params.id);
      const book = await storage.getBook(bookId);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      const chapters = await storage.getChaptersByBookId(bookId);
      if (chapters.length === 0) {
        return res.status(400).json({ message: "Book has no content to download" });
      }
      
      // Create a text file with book content
      let bookContent = `${book.title}\n\n`;
      
      for (const chapter of chapters) {
        bookContent += `${chapter.title}\n\n${chapter.content}\n\n`;
      }
      
      // Send as download
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="${book.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt"`);
      return res.send(bookContent);
    } catch (error) {
      console.error("Error downloading book:", error);
      return res.status(500).json({ message: "Failed to download book" });
    }
  });
  
  // Mount API router
  app.use("/api", apiRouter);
  
  // Async function to generate a book
  async function generateBook(bookId: number, bookData: z.infer<typeof bookGenerationSchema>) {
    try {
      // Update status to generating outline
      await storage.createGenerationStatus({
        bookId,
        status: "generating_outline",
        progress: 5,
        message: "Generating book outline",
        createdAt: new Date().toISOString()
      });
      
      // Generate book outline
      const bookOutline = await generateBookOutline(bookData);
      
      // Update status with outline progress
      await storage.createGenerationStatus({
        bookId,
        status: "generating_chapters",
        progress: 15,
        message: "Book outline created, generating chapters",
        createdAt: new Date().toISOString()
      });
      
      // Start generating chapters one by one
      const totalChapters = bookOutline.outline.length;
      let completedChapters = 0;
      let totalWordCount = 0;
      
      for (const chapterOutline of bookOutline.outline) {
        // Calculate progress percentage
        const progressPercentage = Math.floor(15 + ((completedChapters / totalChapters) * 80));
        
        // Update status for current chapter
        await storage.createGenerationStatus({
          bookId,
          status: "generating_chapters",
          progress: progressPercentage,
          message: `Generating chapter: ${chapterOutline.title}`,
          createdAt: new Date().toISOString()
        });
        
        // Generate chapter content
        const chapterContent = await generateChapter(
          bookOutline.title,
          bookData.genre,
          bookData.writingStyle,
          bookData.pov,
          chapterOutline
        );
        
        // Save chapter to storage
        await storage.createChapter({
          bookId,
          title: chapterContent.title,
          content: chapterContent.content,
          orderIndex: completedChapters
        });
        
        // Update word count and completed chapters
        totalWordCount += chapterContent.actualWordCount;
        completedChapters++;
      }
      
      // Update book with completion status and word count
      await storage.updateBook(bookId, {
        status: "completed",
        wordCount: totalWordCount
      });
      
      // Final status update
      await storage.createGenerationStatus({
        bookId,
        status: "completed",
        progress: 100,
        message: "Book generation completed successfully",
        createdAt: new Date().toISOString()
      });
      
    } catch (error) {
      console.error(`Error generating book ${bookId}:`, error);
      
      // Update status with error
      await storage.createGenerationStatus({
        bookId,
        status: "error",
        progress: 0,
        message: `Error generating book: ${error instanceof Error ? error.message : String(error)}`,
        createdAt: new Date().toISOString()
      });
      
      // Update book status to error
      await storage.updateBook(bookId, {
        status: "error"
      });
    }
  }

  const httpServer = createServer(app);
  return httpServer;
}
