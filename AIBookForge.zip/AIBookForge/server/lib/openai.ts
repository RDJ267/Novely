import OpenAI from "openai";
import { BookGeneration, Character } from "@shared/schema";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "dummy-api-key-for-development" 
});

// Prompts for the AI generation
const BOOK_OUTLINE_PROMPT = `
You are a professional book author tasked with creating a detailed outline for a novel. Based on the following inputs:

Title: {title}
Genre: {genre}
Storyline: {storyline}
Characters:
{characters}
Key Scenes: {keyScenes}
Additional Notes: {additionalNotes}
Writing Style: {writingStyle}
Point of View: {pov}

Create a detailed chapter-by-chapter outline for a novel of 85,000 words. Include 15-25 chapters plus a prologue and epilogue if appropriate.

For each chapter, provide:
1. Chapter title
2. Brief summary (2-3 sentences)
3. Key plot points and character developments
4. Word count estimate (total should be approximately 85,000 words)

Present your response in JSON format with the following structure:
{
  "title": "Final Book Title",
  "outline": [
    {
      "type": "prologue|chapter|epilogue",
      "title": "Chapter Title",
      "summary": "Brief summary",
      "content": "Key plot points and developments",
      "wordCount": 0000
    }
  ],
  "totalWordCount": 85000
}
`;

const CHAPTER_GENERATION_PROMPT = `
You are a professional author writing a chapter for a novel. Write a complete, polished chapter based on the following outline:

Book Title: {bookTitle}
Genre: {genre}
Writing Style: {writingStyle}
Point of View: {pov}

Chapter Type: {chapterType}
Chapter Title: {chapterTitle}
Chapter Summary: {chapterSummary}
Chapter Details: {chapterContent}
Target Word Count: {wordCount} words

Important instructions:
1. Write a complete, engaging chapter that matches the outlined plot points
2. Follow the specified writing style and point of view
3. Use vivid descriptions and natural dialogue
4. Include scene breaks where appropriate
5. Aim for approximately {wordCount} words
6. Do not summarize or leave notes - write the actual full chapter text

Present your response in JSON format with the following structure:
{
  "title": "Chapter Title",
  "content": "The full chapter text with proper paragraphs",
  "actualWordCount": 0000
}
`;

// Interfaces for the AI responses
interface ChapterOutline {
  type: "prologue" | "chapter" | "epilogue";
  title: string;
  summary: string;
  content: string;
  wordCount: number;
}

interface BookOutline {
  title: string;
  outline: ChapterOutline[];
  totalWordCount: number;
}

interface ChapterContent {
  title: string;
  content: string;
  actualWordCount: number;
}

// Function to format characters for the prompt
function formatCharacters(characters: Character[]): string {
  return characters.map(char => 
    `- Name: ${char.name}\n  Role: ${char.role}\n  Description: ${char.description}`
  ).join('\n\n');
}

// Generate a complete book outline based on user inputs
export async function generateBookOutline(bookData: BookGeneration): Promise<BookOutline> {
  const formattedCharacters = formatCharacters(bookData.characters);
  
  const prompt = BOOK_OUTLINE_PROMPT
    .replace('{title}', bookData.title)
    .replace('{genre}', bookData.genre)
    .replace('{storyline}', bookData.storyline)
    .replace('{characters}', formattedCharacters)
    .replace('{keyScenes}', bookData.keyScenes)
    .replace('{additionalNotes}', bookData.additionalNotes || 'None')
    .replace('{writingStyle}', bookData.writingStyle)
    .replace('{pov}', bookData.pov);

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }

    return JSON.parse(content) as BookOutline;
  } catch (error) {
    console.error("Error generating book outline:", error);
    throw new Error(`Failed to generate book outline: ${error instanceof Error ? error.message : String(error)}`);
  }
}

// Generate a single chapter based on the outline
export async function generateChapter(
  bookTitle: string,
  genre: string,
  writingStyle: string,
  pov: string,
  chapter: ChapterOutline
): Promise<ChapterContent> {
  const prompt = CHAPTER_GENERATION_PROMPT
    .replace('{bookTitle}', bookTitle)
    .replace('{genre}', genre)
    .replace('{writingStyle}', writingStyle)
    .replace('{pov}', pov)
    .replace('{chapterType}', chapter.type)
    .replace('{chapterTitle}', chapter.title)
    .replace('{chapterSummary}', chapter.summary)
    .replace('{chapterContent}', chapter.content)
    .replace(/\{wordCount\}/g, String(chapter.wordCount));

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }

    return JSON.parse(content) as ChapterContent;
  } catch (error) {
    console.error(`Error generating chapter "${chapter.title}":`, error);
    throw new Error(`Failed to generate chapter: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export default {
  generateBookOutline,
  generateChapter
};
