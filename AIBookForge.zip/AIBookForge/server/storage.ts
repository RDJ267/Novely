import {
  users,
  type User,
  type InsertUser,
  books,
  type Book,
  type InsertBook,
  chapters,
  type Chapter,
  type InsertChapter,
  generationStatuses,
  type GenerationStatus,
  type InsertGenerationStatus,
  type Character
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Book operations
  getBook(id: number): Promise<Book | undefined>;
  createBook(book: InsertBook): Promise<Book>;
  updateBook(id: number, book: Partial<Book>): Promise<Book | undefined>;
  listBooks(userId?: number): Promise<Book[]>;

  // Chapter operations
  getChapter(id: number): Promise<Chapter | undefined>;
  getChaptersByBookId(bookId: number): Promise<Chapter[]>;
  createChapter(chapter: InsertChapter): Promise<Chapter>;
  
  // Generation status operations
  getGenerationStatus(id: number): Promise<GenerationStatus | undefined>;
  getLatestGenerationStatus(bookId: number): Promise<GenerationStatus | undefined>;
  createGenerationStatus(status: InsertGenerationStatus): Promise<GenerationStatus>;
  updateGenerationStatus(id: number, status: Partial<InsertGenerationStatus>): Promise<GenerationStatus | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private books: Map<number, Book>;
  private chapters: Map<number, Chapter>;
  private generationStatuses: Map<number, GenerationStatus>;

  private currentUserId: number;
  private currentBookId: number;
  private currentChapterId: number;
  private currentStatusId: number;

  constructor() {
    this.users = new Map();
    this.books = new Map();
    this.chapters = new Map();
    this.generationStatuses = new Map();

    this.currentUserId = 1;
    this.currentBookId = 1;
    this.currentChapterId = 1;
    this.currentStatusId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Book operations
  async getBook(id: number): Promise<Book | undefined> {
    return this.books.get(id);
  }

  async createBook(insertBook: InsertBook): Promise<Book> {
    const id = this.currentBookId++;
    const book: Book = {
      ...insertBook,
      id,
      status: "pending",
      content: null,
      wordCount: null,
      createdAt: new Date().toISOString(),
    };
    this.books.set(id, book);
    return book;
  }

  async updateBook(id: number, bookUpdate: Partial<Book>): Promise<Book | undefined> {
    const book = this.books.get(id);
    if (!book) return undefined;

    const updatedBook = { ...book, ...bookUpdate };
    this.books.set(id, updatedBook);
    return updatedBook;
  }

  async listBooks(userId?: number): Promise<Book[]> {
    const allBooks = Array.from(this.books.values());
    if (userId) {
      return allBooks.filter(book => book.userId === userId);
    }
    return allBooks;
  }

  // Chapter operations
  async getChapter(id: number): Promise<Chapter | undefined> {
    return this.chapters.get(id);
  }

  async getChaptersByBookId(bookId: number): Promise<Chapter[]> {
    return Array.from(this.chapters.values())
      .filter(chapter => chapter.bookId === bookId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async createChapter(insertChapter: InsertChapter): Promise<Chapter> {
    const id = this.currentChapterId++;
    const chapter: Chapter = { ...insertChapter, id };
    this.chapters.set(id, chapter);
    return chapter;
  }

  // Generation status operations
  async getGenerationStatus(id: number): Promise<GenerationStatus | undefined> {
    return this.generationStatuses.get(id);
  }

  async getLatestGenerationStatus(bookId: number): Promise<GenerationStatus | undefined> {
    const statuses = Array.from(this.generationStatuses.values())
      .filter(status => status.bookId === bookId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return statuses.length > 0 ? statuses[0] : undefined;
  }

  async createGenerationStatus(insertStatus: InsertGenerationStatus): Promise<GenerationStatus> {
    const id = this.currentStatusId++;
    const status: GenerationStatus = { ...insertStatus, id };
    this.generationStatuses.set(id, status);
    return status;
  }

  async updateGenerationStatus(id: number, statusUpdate: Partial<InsertGenerationStatus>): Promise<GenerationStatus | undefined> {
    const status = this.generationStatuses.get(id);
    if (!status) return undefined;

    const updatedStatus = { ...status, ...statusUpdate };
    this.generationStatuses.set(id, updatedStatus);
    return updatedStatus;
  }
}

export const storage = new MemStorage();
